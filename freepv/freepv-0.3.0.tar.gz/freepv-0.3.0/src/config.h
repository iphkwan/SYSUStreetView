

/* Define to 1 if you have <GL/freeglut.h>. */
#define HAVE_FREEGLUT_H 1

/* Define to 1 if you have <GL/glut.h>. */
#define HAVE_GLUT_H 1

/* Define to 1 if you have OSX style <GLUT/glut.h>. */
/* #undef HAVE_OSXGLUT_H 1 */

/* Define to 1 if you have gettimeofday() */
#define HAVE_GETTIMEOFDAY 1

/* Define to 1 if X11 was found */
#define MOZ_X11 1

/* Define to 1 if XF86vmode.h include was found */
/* #undef HAVE_XF86VMODE_H 1 */

/* Define to 1 if you have are under Unix */
#define XP_UNIX 1

/* Define to 1 if you have are under Windows */
/* #undef XP_WIN 1 */

